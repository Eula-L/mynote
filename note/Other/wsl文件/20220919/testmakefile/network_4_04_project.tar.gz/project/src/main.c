#include<stdio.h>


#include"common.h"


int main(void)
{
	int num = add( 2 , 3);
	printf("2+3 = %d\n" , num );

	return 0;
}
