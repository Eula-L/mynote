#pragma once


int add(int a , int b);
int sub(int a , int b);
int mul(int a , int b);
int des(int a , int b);
